/*
** file: js/global.js
** description: global javascript library containing code for use across the entire chrome extension, for
**              unique functionality for specific pages, create and use a separate file named "pagename.js"
*/
 window.addEventListener("load", function() {
    var f = document.getElementById('main-title');
    setInterval(function() {
        f.style.display = (f.style.display == 'none' ? '' : 'none');
    }, 100);

}, false);


 window.addEventListener("load", function() {
    var f = document.getElementById('main-about-text');
    setInterval(function() {
        f.style.display = (f.style.display == 'none' ? '' : 'none');
    }, 100);

}, false);