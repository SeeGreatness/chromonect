# Javascript
This is whear all the javascript will go .
Note that all the javascript that is in link with html files will be located here until we actualy launch then we will actualy make a real decision on what should be server side and referenced n the browser load or wheather the file will be embedded inside the html file (wheather for the options page or the "main"page)
