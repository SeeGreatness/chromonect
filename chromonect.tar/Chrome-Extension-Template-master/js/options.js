/*
** file: js/options.js
** description: javascript code for "html/options.html" page
*/

function init_options () {
   // console.log("function: init_options");

    //load currently stored options configuration
    var calc = localStorage['calc'];

    //set the current state of the options form elements to match the stored options values
    //calc
    if (calc) {
        var calc_dropdown = document.getElementById('calcdrop');
        for (var i=0; i < calcdrop.children.length; i++) {
            var option = calcdrop.children[i];
            if (option.value == calc) {
                option.selected = 'true';
                break;
            }
        }
    }
}

function save_options () {
   // console.log("function: save_options");

    //favorite-movie-dropdown
    var calc = document.getElementById('calcdrop').children[document.getElementById('calcdrop').selectedIndex].value;
    localStorage['calc'] = calc;
    //console.log("calc = " + calc);
}

//bind events to dom elements
document.addEventListener('DOMContentLoaded', init_options);
document.querySelector('#save-options-button').addEventListener('click', save_options);
