<html>
    <head>
    </head>
    <body>
        <h2>TI-Chromnect</h2>
        <div><b>Version:</b> 0.001 PRE-RELESE</div>
        <div><b>Author #1:</b> SeeGreatness (seegreatness@tichromnect.honor.es)</div>
        <div><b>Author #2:</b> Jacob-Kuschel (Jacob@letsdosomethingcool.com)</div>
        <div><b>Author #3:</b> pieman3737 (pieman@tichromnect.honor.es)</div>
        <div><b>Author #4:</b> bowTiesAreCool (colin@tichromnect.honor.es)</div>
        <div><b>Updated:</b> 2017.april.27</div>
        <div><b>Description:</b> A version of TI-Connect for Chrome!</div>
        <div><b>Official Google Getting Started Guide:</b> http://developer.chrome.com/extensions/getstarted.html</div>
        <div><b>Bundled Software / Libraries:</b></div>
        <div>
            <ul>
                <li>jQuery 1.9.1: http://jquery.com/</li>
                <li>Bootstrap 2.3.1: http://twitter.github.com/bootstrap/index.html</li>
                <li>Font Awesome 3.0.2: http://fortawesome.github.io/Font-Awesome/</li>
            </ul>
            </div>
    </body>
</html>
