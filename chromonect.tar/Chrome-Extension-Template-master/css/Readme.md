# CSS
THis is where all the style happns a css file is a cascading style sheet or css for short.
you can define how something should look, what font it should be, how big text should be and you can program any animations that are in the html file such as a loading screen 
you can also use css to hide something from being visible from the user
the possibilitys with css and style are endless (some conditions apply)
